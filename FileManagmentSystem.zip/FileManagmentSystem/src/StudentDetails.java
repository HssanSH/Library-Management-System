class StudentDetails {
    String name;
    String fname;
    String uni_id;
    int u_id;
    int sem;
    String department;

    public void getdata(String name, String fname, String uni_id, int u_id, int sem) {
        this.name = name;
        this.fname = fname;
        this.uni_id = uni_id;
        this.u_id = u_id;
        this.sem = sem;
    }

    public void setdata() {
        System.out.println("Student's Name: " + name);
        System.out.println("Father's Name: " + fname);
        System.out.println("Student's University Id: " + uni_id);
        System.out.println("Student's User Id: " + u_id);
        System.out.println("Student's Semester: " + sem);
        System.out.println("Student's Department: " + department);
    }
}
