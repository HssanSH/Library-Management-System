import java.util.Scanner;

class Menu {
    private String[] menuOptions;
    private int currentOption;
    private boolean isRunning;

    public Menu() {
        menuOptions = new String[]{"Add student credentials", "See departments", "Borrow book", "Exit"};
        currentOption = 0;
        isRunning = true;
    }

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.println("Welcome to Library Management System");
        System.out.println("Choose between the following:");
        System.out.println("Enter 1 to add student credentials"); // Prompt for adding student credentials
        System.out.println("Enter 2 to see Chemistry, 3 for Physics, 4 for Mathematics, 5 for Technology, 6 for History"); // Prompt for department selection
        System.out.println("Enter 7 to borrow");// Prompt for borrowing a book
        System.out.println("Enter 8 to terminate program");
        System.out.println("Enter your choice: "); // Prompt for user's choice

        int num = 0; // Initialize num to avoid compilation error
        while (num != 8) {
            num = obj.nextInt();
            obj.nextLine(); // Consume the newline character after reading the number

            if (num == 1) {
                StudentDetails obj1 = new StudentDetails();
                System.out.println("Enter the name of the student: "); // Prompt for student's name
                obj1.name = obj.nextLine();

                System.out.println("Enter student's Father name: "); // Prompt for student's father's name
                obj1.fname = obj.nextLine();

                System.out.println("Enter Student's University Id: "); // Prompt for student's university ID
                obj1.uni_id = obj.nextLine();

                System.out.println("Enter Student's User Id: "); // Prompt for student's user ID
                obj1.u_id = obj.nextInt();

                System.out.println("Enter Student's Semester number: "); // Prompt for student's semester number
                obj1.sem = obj.nextInt();

                obj.nextLine(); // Consume the newline character after reading the number

                System.out.println("Enter Student's Department: "); // Prompt for student's department
                obj1.department = obj.nextLine();

                obj1.getdata(obj1.name, obj1.fname, obj1.uni_id, obj1.u_id, obj1.sem);
                obj1.setdata();

                System.out.println("Enter your choice: "); // Prompt for user's choice
            } else if (num == 2) {
                Departments obj2 = new Departments();
                obj2.chemistry(); // Display chemistry department information
                System.out.println("Enter your choice: "); // Prompt for user's choice
            } else if (num == 3) {
                Departments obj2 = new Departments();
                obj2.physics(); // Display physics department information
                System.out.println("Enter your choice: "); // Prompt for user's choice
            } else if (num == 4) {
                Departments obj2 = new Departments();
                obj2.mathematics(); // Display mathematics department information
                System.out.println("Enter your choice: "); // Prompt for user's choice
            } else if (num == 5) {
                Departments obj2 = new Departments();
                obj2.history(); // Display history department information
                System.out.println("Enter your choice: "); // Prompt for user's choice
            } else if (num == 6) {
                Departments obj2 = new Departments();
                obj2.tech(); // Display technology department information
                System.out.println("Enter your choice: "); // Prompt for user's choice
            } else if (num == 7) {
                Departments obj2 = new Departments();
                System.out.println("Enter Book name you would like to borrow: "); // Prompt for book selection to borrow
                obj2.bname = obj.nextLine(); // Store the book name to borrow

                StudentDetails obj1 = new StudentDetails();
                System.out.println("Enter Student's Department: "); // Prompt for student's department
                obj1.department = obj.nextLine(); // Store the student's department

                obj2.displayBooksByDepartment(obj1.department); // Display books based on the student's department

                System.out.println("Enter your choice: "); // Prompt for user's choice
            }
        }
    }
}

