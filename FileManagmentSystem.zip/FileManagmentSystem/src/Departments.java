class Departments {
    String bname;

    // Method to display available books in the Chemistry department
    public void chemistry() {
        System.out.println("Chemistry department selected.");
        System.out.println("Available books in Chemistry department: ");
        System.out.println("1. Organic Chemistry");
        System.out.println("2. Inorganic Chemistry");
        System.out.println("3. Physical Chemistry");
    }

    // Method to display available books in the Physics department
    public void physics() {
        System.out.println("Physics department selected.");
        System.out.println("Available books in Physics department: ");
        System.out.println("1. Classical Mechanics");
        System.out.println("2. Quantum Mechanics");
        System.out.println("3. Electromagnetism");
    }

    // Method to display available books in the Mathematics department
    public void mathematics() {
        System.out.println("Mathematics department selected.");
        System.out.println("Available books in Mathematics department: ");
        System.out.println("1. Calculus");
        System.out.println("2. Linear Algebra");
        System.out.println("3. Discrete Mathematics");
    }

    // Method to display available books in the History department
    public void history() {
        System.out.println("History department selected.");
        System.out.println("Available books in History department: ");
        System.out.println("1. World History");
        System.out.println("2. European History");
        System.out.println("3. Asian History");
    }

    // Method to display available books in the Technology department
    public void tech() {
        System.out.println("Technology department selected.");
        System.out.println("Available books in Technology department: ");
        System.out.println("1. Introduction to Programming");
        System.out.println("2. Data Structures and Algorithms");
        System.out.println("3. Web Development");
    }

    // Method to display books based on the student's department
    public void displayBooksByDepartment(String department) {
        switch (department) {
            case "Chemistry":
                chemistry();
                break;
            case "Physics":
                physics();
                break;
            case "Mathematics":
                mathematics();
                break;
            case "History":
                history();
                break;
            case "Technology":
                tech();
                break;
            default:
                System.out.println("Invalid department");
        }

        System.out.println("Borrowing book: " + bname);
    }
}
